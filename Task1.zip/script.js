// script.js

function showMessage() {
  alert("Hello! Thanks for clicking the button!");
}
